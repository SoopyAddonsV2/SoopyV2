package me.soopyboo32.soopyv2forge;

public interface RenderHudAble {
    void render(float partialTicks);
}
