package me.soopyboo32.soopyv2forge;

public interface RenderWorldAble {
    void render(float partialTicks);
}
